These archive files contain the source code for examples discussed on developerglowingpigs' YouTube channel.
The source code is for your convenience purposes only. The source code is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

